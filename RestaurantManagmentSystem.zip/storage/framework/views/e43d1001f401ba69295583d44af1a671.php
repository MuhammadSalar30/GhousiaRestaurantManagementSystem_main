<?php echo $__env->make('layouts.shared/preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- End Header -->
<header class="sticky top-0 h-18 flex z-40 w-full border-b border-default-200 bg-white dark:bg-default-50 lg:ps-64">
    <nav class="flex items-center gap-4 w-full px-6">
        <!-- Navigation Toggle (in Small Screen) -->
        <div class="lg:hidden flex">
            <button type="button" class="text-default-500 hover:text-default-600" data-hs-overlay="#application-sidebar" aria-controls="application-sidebar" aria-label="Toggle navigation">
                <i data-lucide="align-justify" class="w-6 h-6"></i>
            </button>
        </div>

        <!-- Logo -->
        <div class="lg:hidden flex">
            <a href="<?php echo e(route('second', ['admin', 'dashboard'])); ?>">
             <img src="/images/assets/logo.png" alt="logo" class="h-10 flex dark:hidden">
             <img src="/images/assets/logo.png" alt="logo" class="h-12 hidden dark:flex">
                
            </a>
        </div>

        <!-- Search Input -->
        <div class="lg:flex hidden">
            <label for="icon" class="sr-only">Search</label>
            <div class="relative lg:flex hidden">
                <input type="search" class="ps-12 pe-4 py-2.5 block w-64 bg-default-50 text-default-600 border-default-200 rounded-full text-sm focus:border-primary focus:ring-primary" placeholder="Search for items...">
                <span class="absolute start-4 top-2.5">
                    <i data-lucide="search" class="w-5 h-5 text-default-600"></i>
                </span>
            </div>
        </div>

        <!-- Topbar Link and Dropdown Button -->
        <div class="flex items-center gap-4 ms-auto">
            <!-- Language -->
            <div class="lg:flex hidden">
                <div class="hs-dropdown relative inline-flex [--placement:bottom-right]">
                    <button id="hs-dropdown-with-header" type="button" class="hs-dropdown-toggle inline-flex flex-shrink-0 justify-center items-center gap-2 h-10 w-10 rounded-full font-medium text-default-700 align-middle bg-default-100 hover:text-primary transition-all text-xs">
                        <i data-lucide="globe" class="w-6 h-6"></i>
                    </button>

                    <div class="hs-dropdown-menu mt-2 transition-[opacity,margin] duration hs-dropdown-open:opacity-100 opacity-0 hidden min-w-[12rem] shadow-md rounded-lg border border-default-200 bg-white dark:bg-default-50 p-2">
                        <a class="flex items-center gap-x-3.5 py-2 px-3 text-sm rounded transition-all hover:bg-default-100" href="javascript:void(0)">
                            <img src="/images/flags/germany.jpg" alt="user-image" class="h-4">
                            <span class="align-middle">German</span>
                        </a>
                        <a class="flex items-center gap-x-3.5 py-2 px-3 text-sm rounded transition-all hover:bg-default-100" href="javascript:void(0)">
                            <img src="/images/flags/italy.jpg" alt="user-image" class="h-4">
                            <span class="align-middle">Italian</span>
                        </a>
                        <a class="flex items-center gap-x-3.5 py-2 px-3 text-sm rounded transition-all hover:bg-default-100" href="javascript:void(0)">
                            <img src="/images/flags/spain.jpg" alt="user-image" class="h-4">
                            <span class="align-middle">Spanish</span>
                        </a>
                        <a class="flex items-center gap-x-3.5 py-2 px-3 text-sm rounded transition-all hover:bg-default-100" href="javascript:void(0)">
                            <img src="/images/flags/russia.jpg" alt="user-image" class="h-4">
                            <span class="align-middle">Russian</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Fullscreen Button -->
            <div class="lg:flex hidden">
                <button data-toggle="fullscreen" class="inline-flex flex-shrink-0 justify-center items-center gap-2 h-10 w-10 rounded-full font-medium text-default-700 align-middle bg-default-100 hover:text-primary transition-all text-xs">
                    <i data-lucide="maximize" class="w-6 h-6"></i>
                </button>
            </div>

            <!-- Setting Button -->
            <div class="md:flex hidden">
                <a href="<?php echo e(route('second', ['admin', 'settings'])); ?>" class="inline-flex flex-shrink-0 justify-center items-center gap-2 h-10 w-10 rounded-full font-medium text-default-700 align-middle bg-default-100 hover:text-primary transition-all text-xs">
                    <i data-lucide="settings" class="w-6 h-6"></i>
                </a>
            </div>

            <!-- Notification Dropdown -->
            <div class="md:flex hidden">
                <div class="hs-dropdown relative inline-flex [--placement:bottom-right]">
                    <button id="hs-dropdown-with-header" type="button" class="hs-dropdown-toggle inline-flex flex-shrink-0 justify-center items-center gap-2 h-10 w-10 rounded-full font-medium text-default-700 align-middle bg-default-100 hover:text-primary transition-all text-xs">
                        <i data-lucide="bell" class="w-6 h-6"></i>
                        <span class="absolute top-0 end-1 h-4 w-4 bg-yellow-500 rounded-full animate-ping"></span>
                        <span class="absolute top-0 end-1 h-4 w-4 bg-yellow-500 text-xs font-medium text-white rounded-full">2</span>
                    </button>

                    <div class="hs-dropdown-menu mt-2 transition-[opacity,margin] duration hs-dropdown-open:opacity-100 opacity-0 hidden min-w-[20rem] shadow-md rounded-lg border border-default-200 bg-white dark:bg-default-50">
                        <div class="px-4 py-2 flex items-center justify-between">
                            <h6 class="text-sm font-medium"> Notification</h6>
                            <a href="javascript: void(0);" class="text-default-500">
                                <small>Clear All</small>
                            </a>
                        </div>

                        <div class="p-4 h-80 border-y border-dashed border-default-200" data-simplebar>
                            <h5 class="text-xs text-default-700 mb-2">Today</h5>

                            <a href="javascript:void(0);" class="flex items-center mb-4">
                                <img src="/images/avatars/avatar1.png" class="rounded-full h-10 w-10">
                                <div class="flex-grow truncate ms-2">
                                    <div class="flex items-center justify-between">
                                        <h5 class="text-sm font-medium text-default-800">Datacorp </h5>
                                        <small class="inline-flex text-xs text-default-500">1 min ago</small>
                                    </div>
                                    <small class="text-default-400">Caleb Flakelar commented on Admin</small>
                                </div>
                            </a>

                            <a href="javascript:void(0);" class="flex items-center mb-4">
                                <div class="flex-shrink-0">
                                    <img src="/images/avatars/avatar2.png" class="rounded-full h-10 w-10">
                                </div>
                                <div class="flex-grow truncate ms-2">
                                    <div class="flex items-center justify-between">
                                        <h5 class="text-sm font-medium text-default-800">Admin </h5>
                                        <small class="inline-flex text-xs text-default-500">1 hr ago</small>
                                    </div>
                                    <small class="text-default-400">New user registered</small>
                                </div>
                            </a>

                            <a href="javascript:void(0);" class="flex items-center mb-4">
                                <div class="flex-shrink-0">
                                    <img src="/images/avatars/avatar3.png" class="rounded-full h-10 w-10">
                                </div>
                                <div class="flex-grow truncate ms-2">
                                    <div class="flex items-center justify-between">
                                        <h5 class="text-sm font-medium text-default-800">Cristina Pride </h5>
                                        <small class="inline-flex text-xs text-default-500">1 day ago</small>
                                    </div>
                                    <small class="text-default-400">Hi, How are you? What about our next meeting</small>
                                </div>
                            </a>

                            <h5 class="text-xs text-default-700 mb-2">Yesterday</h5>

                            <a href="javascript:void(0);" class="flex items-center mb-4">
                                <div class="flex-shrink-0">
                                    <img src="/images/avatars/avatar4.png" class="rounded-full h-10 w-10">
                                </div>
                                <div class="flex-grow truncate ms-2">
                                    <h5 class="text-sm font-semibold mb-1">Datacorp</h5>
                                    <small class="text-default-400">Caleb Flakelar commented on Admin</small>
                                </div>
                            </a>

                            <a href="javascript:void(0);" class="flex">
                                <div class="flex-shrink-0">
                                    <img src="/images/avatars/avatar5.png" class="rounded-full h-10 w-10">
                                </div>
                                <div class="flex-grow truncate ms-2">
                                    <h5 class="text-sm font-semibold mb-1">Karen Robinson</h5>
                                    <small class="text-default-400">Wow ! this admin looks good and awesome design</small>
                                </div>
                            </a>
                        </div>

                        <a href="javascript:void(0);" class="px-4 py-2 block text-center text-primary font-medium text-sm">
                            View All
                        </a>
                    </div>
                </div>
            </div>

            <!-- Profile Dropdown -->
            <div class="flex">
                <div class="hs-dropdown relative inline-flex ">
                    <button id="hs-dropdown-with-header" type="button" class="hs-dropdown-toggle inline-flex flex-shrink-0 justify-center items-center gap-2 rounded-full font-medium text-default-700 align-middle transition-all text-xs">
                        <img class="inline-block h-10 w-10 rounded-full" src="/images/avatars/avatar1.png">
                        <div class="lg:block text-start hidden">
                            <p class="text-sm font-medium text-default-700">Kaiya Botosh</p>
                            <p class="text-xs text-default-500 mt-1">Admin</p>
                        </div>
                    </button>

                    <div class="hs-dropdown-menu mt-2 transition-[opacity,margin] duration hs-dropdown-open:opacity-100 opacity-0 hidden min-w-[12rem] shadow-md rounded-lg p-2 border border-default-200 bg-white dark:bg-default-50">
                        <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-md text-sm text-default-800 transition-all hover:bg-default-100" href="<?php echo e(route('second', ['admin', 'settings'])); ?>">
                            <i class="w-4 h-4" data-lucide="user"></i>
                            My Profile
                        </a>
                        <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-md text-sm text-default-800 transition-all hover:bg-default-100" href="<?php echo e(route('second', ['client','home'])); ?>" target="_blank">
                            <i class="w-4 h-4" data-lucide="newspaper"></i>
                            Landing
                        </a>
                        <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-md text-sm text-default-800 transition-all hover:bg-default-100" href="<?php echo e(route('second', ['admin', 'settings'])); ?>">
                            <i class="w-4 h-4" data-lucide="settings"></i>
                            Setting
                        </a>

                        <hr class="my-2 border-default-200 -mx-2">

                        <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-md text-sm text-red-400 hover:bg-red-400/10" href="javascript:void(0)">
                            <i class="w-4 h-4" data-lucide="log-out"></i>
                            Log out
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>
<!-- End Header -->
<?php /**PATH D:\SALAR_WEB\Salar Work\RestaurantManagmentSystem\resources\views/layouts/shared/admin-topbar.blade.php ENDPATH**/ ?>