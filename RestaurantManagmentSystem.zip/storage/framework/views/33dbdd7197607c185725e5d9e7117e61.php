<?php $__env->startSection('content'); ?>

<div class="grid grid-cols-1">
    <div class="border rounded-lg border-default-200">
        <div class="px-6 py-4 overflow-hidden ">
            <div class="flex flex-wrap md:flex-nowrap items-center justify-between gap-4">
                <h2 class="text-xl text-default-800 font-semibold">Item List</h2>

                <div class="flex flex-wrap items-center gap-4">
                    <div class="hs-dropdown relative inline-flex [--placement:bottom-right]">
                        <button type="button" class="hs-dropdown-toggle flex items-center gap-2 font-medium text-default-700 text-sm py-2.5 px-4 rounded-md bg-default-100 transition-all">
                            Save as Draft <i data-lucide="chevron-down" class="h-4 w-4"></i>
                        </button><!-- end dropdown button -->

                        <div class="hs-dropdown-menu hs-dropdown-open:opacity-100 min-w-[200px] transition-[opacity,margin] mt-4 opacity-0 hidden z-20 bg-white shadow-[rgba(17,_17,_26,_0.1)_0px_0px_16px] rounded-lg border border-default-100 p-1.5 dark:bg-default-50">
                            <ul class="flex flex-col gap-1">
                                <li><a class="flex items-center gap-3 font-normal py-2 px-3 transition-all text-default-700 bg-default-100 rounded" href="javascript:void(0)">All</a></li>
                                <li><a class="flex items-center gap-3 font-normal text-default-600 py-2 px-3 transition-all hover:text-default-700 hover:bg-default-100 rounded" href="javascript:void(0)">Publish</a></li>
                                <li><a class="flex items-center gap-3 font-normal text-default-600 py-2 px-3 transition-all hover:text-default-700 hover:bg-default-100 rounded" href="javascript:void(0)">Save as Draft</a></li>
                                <li><a class="flex items-center gap-3 font-normal text-default-600 py-2 px-3 transition-all hover:text-default-700 hover:bg-default-100 rounded" href="javascript:void(0)">Discard</a></li>
                            </ul><!-- end dropdown items -->
                        </div><!-- end dropdown menu -->
                    </div>
                    <a href="<?php echo e(route('second', ['products', 'add'])); ?>" class="py-2.5 px-4 inline-flex rounded-lg text-sm font-medium bg-primary text-white transition-all hover:bg-primary-500">Add Product</a>
                </div>
            </div>
        </div>

        <div class="relative overflow-x-auto">
            <div class="min-w-full inline-block align-middle">
                <div class="overflow-hidden">
                    <table class="min-w-full divide-y divide-default-200">
                        <thead class="bg-default-100">
                            <tr class="text-start">
                                <th class="px-6 py-3 text-start text-sm whitespace-nowrap font-medium text-default-800">Product</th>
                                <th class="px-6 py-3 text-start text-sm whitespace-nowrap font-medium text-default-800">Category</th>
                                <th class="px-6 py-3 text-start text-sm whitespace-nowrap font-medium text-default-800">Price</th>
                                <th class="px-6 py-3 text-start text-sm whitespace-nowrap font-medium text-default-800">Size</th>
                                <th class="px-6 py-3 text-start text-sm whitespace-nowrap font-medium text-default-800">Description</th>
                                
                                <th class="px-6 py-3 text-start text-sm whitespace-nowrap font-medium text-default-800">Status</th>
                                <th class="px-6 py-3 text-start text-sm whitespace-nowrap font-medium text-default-800">Action</th>
                            </tr><!-- end table-head-row -->
                        </thead><!-- end t-head -->
                        <tbody class="divide-y divide-default-200">
                            <?php $__currentLoopData = AllItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-default-800">
                                    <a href="<?php echo e(route('third', ['products', 'details', $item->id])); ?>" class="flex items-center gap-3">
                                        <div class="shrink">
                                            
                                            <img src="<?php echo e($item->image ? asset($item->image) : '/images/dishes/small/pizza.png'); ?>" class="h-12 w-12">
                                        </div>
                                        <p class="text-base text-default-500 transition-all hover:text-primary"><?php echo e($item->name); ?></p>
                                    </a>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-default-500"><?php echo e(GetCategoryName($item->menu_section_id)); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-default-500">PKR <?php echo e($item->price); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-default-500"><?php echo e($item->size ? ucfirst($item->size) : '-'); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-default-500"><?php echo e(strip_tags($item->description)); ?></td>
                                
                                <td class="px-6 py-4">
                                    <span class="inline-flex items-center gap-1 py-0.5 px-2.5 rounded-full text-xs font-medium bg-green-500/20 text-green-500"><?php echo e($item->status); ?></span>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex gap-3">
                                        <a href="<?php echo e(route('third', ['products', 'edit', $item->id])); ?>" class="transition-all hover:text-primary"><i data-lucide="pencil" class="w-5 h-5"></i></a>
                                        <a href="<?php echo e(route('third', ['products', 'details', $item->id])); ?>" class="transition-all hover:text-primary"><i data-lucide="eye" class="w-5 h-5"></i></a>
                                        <a href="javascript:void(0)" data-action="delete" data-id="<?php echo e($item->id); ?>" class="transition-all hover:text-red-500"><i data-lucide="trash-2" class="w-5 h-5"></i></a>
                                    </div>
                                </td>
                            </tr><!-- end table-row -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                        </tbody><!-- end t-body -->
                    </table><!-- end table -->
                </div><!-- end overflo-hidden -->
            </div><!-- end table-responsive -->
        </div>
    </div>
</div><!-- end grid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$(document).on('click', 'a[data-action="delete"]', function(e) {
    e.preventDefault();
    const id = $(this).data('id');
    if (!confirm('Are you sure you want to delete this product?')) return;
    $.ajax({
        url: '<?php echo e(route('products.delete', ['id' => 'ID_PLACEHOLDER'])); ?>'.replace('ID_PLACEHOLDER', id),
        type: 'DELETE',
        data: {_token: '<?php echo e(csrf_token()); ?>'},
        success: function(){
            location.reload();
        },
        error: function(xhr){
            console.error(xhr.responseText);
            alert('Failed to delete product.');
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['subtitle' => "Products", 'title' => "Products List"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SALAR_WEB\Salar Work\RestaurantManagmentSystem\resources\views/products/list.blade.php ENDPATH**/ ?>