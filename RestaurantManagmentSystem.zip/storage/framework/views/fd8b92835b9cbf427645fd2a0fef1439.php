<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php echo app('Illuminate\Foundation\Vite')(['resources/js/head.js']); ?>
<?php /**PATH D:\SALAR_WEB\Salar Work\RestaurantManagmentSystem\resources\views/layouts/shared/head-css.blade.php ENDPATH**/ ?>