<meta charset="utf-8" />
<title> <?php echo e($title ?? 'Yum'); ?> - Multipurpose Food Tailwind CSS Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="" name="description" />
<meta content="coderthemes" name="author" />

<!-- Theme favicon -->
<link rel="shortcut icon" href="/images/favicon.ico">
<?php /**PATH D:\SALAR_WEB\Salar Work\RestaurantManagmentSystem\resources\views/layouts/shared/title-meta.blade.php ENDPATH**/ ?>