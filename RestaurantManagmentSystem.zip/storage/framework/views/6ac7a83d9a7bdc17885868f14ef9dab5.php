<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<?php /**PATH D:\SALAR_WEB\Salar Work\RestaurantManagmentSystem\resources\views/layouts/shared/main.blade.php ENDPATH**/ ?>