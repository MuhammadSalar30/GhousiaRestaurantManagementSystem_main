

import flatpickr from 'flatpickr';

flatpickr("#datepicker-basic", { defaultDate: new Date() })