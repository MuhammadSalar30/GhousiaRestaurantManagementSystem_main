<!-- CSRF Token -->
<meta name="csrf-token" content="{{ csrf_token() }}">

@vite(['resources/js/head.js'])
