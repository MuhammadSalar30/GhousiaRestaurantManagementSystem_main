@extends('layouts.admin', ['subtitle' => "Products", 'title' => "Products Detail"])

@section('content')

<div class="grid lg:grid-cols-2 gap-6">
    <div class="p-6 border rounded-lg border-default-200">
        <div class="grid grid-cols-1">
            <div>
                <div class="swiper cart-swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="{{ isset($data) && $data ? ($data->image ? asset($data->image) . '?v=' . $data->updated_at->timestamp : '/images/dishes/burrito-bowl.png') : '/images/dishes/burrito-bowl.png' }}" class="max-w-full h-full mx-auto">
                        </div>
                        <div class="swiper-slide">
                            <img src="/images/dishes/burrito-bowl-2.png" class="max-w-full h-full mx-auto">
                        </div>
                        <div class="swiper-slide">
                            <img src="/images/dishes/burrito-bowl-3.png" class="max-w-full h-full mx-auto">
                        </div>
                    </div>
                </div>
            </div>

            <div class="swiper cart-swiper-pagination justify-center">
                <div class="swiper-wrapper justify-center gap-4 w-full">
                    <div class="swiper-slide cursor-pointer !w-20 !h-20 lg:!w-32 lg:!h-32">
                        <img src="{{ isset($data) && $data ? ($data->image ? asset($data->image) . '?v=' . $data->updated_at->timestamp : '/images/dishes/burrito-bowl.png') : '/images/dishes/burrito-bowl.png' }}" class="w-full h-full rounded">
                    </div>
                    <div class="swiper-slide cursor-pointer !w-20 !h-20 lg:!w-32 lg:!h-32">
                        <img src="/images/dishes/burrito-bowl-2.png" class="w-full h-full rounded">
                    </div>
                    <div class="swiper-slide cursor-pointer !w-20 !h-20 lg:!w-32 lg:!h-32">
                        <img src="/images/dishes/burrito-bowl-3.png" class="w-full h-full rounded">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="p-6 border rounded-lg border-default-200">
        <h3 class="text-4xl font-medium text-default-800 mb-1">{{ isset($data) && $data ? $data->name : 'Burrito Bowl' }}</h3>
        <h5 class="text-lg font-medium text-default-600 mb-2"><span class="text-base font-normal text-default-500">by</span> Blaze Pizza</h5>

        <div class="flex items-center gap-3 mb-3">
            <div class="flex gap-1.5">
                <span><i class="fa-solid fa-star text-base text-yellow-400"></i></span>
                <span><i class="fa-solid fa-star text-base text-yellow-400"></i></span>
                <span><i class="fa-solid fa-star text-base text-yellow-400"></i></span>
                <span><i class="fa-solid fa-star text-base text-yellow-400"></i></span>
                <span><i class="fa-solid fa-star-half-stroke text-base text-yellow-400"></i></span>
            </div>
            <div class="h-4 w-px bg-default-400"></div>
            <h5 class="text-sm text-default-500">54 Reviews</h5>
        </div>

        <p class="text-sm text-default-500 mb-4">{{ isset($data) && $data && $data->description ? $data->description : 'Mexican burritos are usually made with a wheat tortilla and contain grilled meat, cheese toppings, and fresh vegetables which are sources of vitamins, proteins, fibers, minerals, and antioxidants. This makes burritos a balanced meal that can be enjoyed in moderation as part of a healthy meal plan.' }}</p>

        <div class="flex flex-wrap gap-2 mb-5">
            <div class="border border-default-200 rounded-full px-3 py-1.5 flex items-center gap-2.5">
                <img src="/images/icons/non-veg.svg" class="w-4 h-4">
                <span class="text-xs">Non Vegetable</span>
            </div>

            <div class="border border-default-200 rounded-full px-3 py-1.5 flex items-center">
                <span class="text-xs">Mexican</span>
            </div>

            <div class="border border-default-200 rounded-full px-3 py-1.5 flex items-center">
                <span class="text-xs">Breakfast</span>
            </div>
        </div>

        <div class="flex items-center gap-3 mb-8">
            <h4 class="text-sm text-default-700">Size :</h4>

            <div>
                <input type="radio" name="option" id="1" value="1" class="peer hidden" checked />
                <label for="1" class="w-9 h-9 flex justify-center items-center cursor-pointer select-none rounded-full text-sm text-center bg-default-200 peer-checked:bg-primary peer-checked:text-white">S</label>
            </div>

            <div>
                <input type="radio" name="option" id="2" value="2" class="peer hidden" />
                <label for="2" class="w-9 h-9 flex justify-center items-center cursor-pointer select-none rounded-full text-sm text-center bg-default-200 peer-checked:bg-primary peer-checked:text-white">M</label>
            </div>

            <div>
                <input type="radio" name="option" id="3" value="3" class="peer hidden" />
                <label for="3" class="w-9 h-9 flex justify-center items-center cursor-pointer select-none rounded-full text-sm text-center bg-default-200 peer-checked:bg-primary peer-checked:text-white">L</label>
            </div>
        </div>

        <div class="flex items-center gap-2 mb-8">
            <div class="relative z-10 inline-flex justify-between border border-default-200 p-1 rounded-full">
                <button type="button" class="minus flex-shrink-0 bg-default-200 text-default-800 rounded-full h-9 w-9 text-sm inline-flex items-center justify-center">–</button>
                <input type="text" class="w-12 border-0 text-sm text-center focus:ring-0 p-0 bg-transparent" value="1" min="0" max="100" readonly="">
                <button type="button" class="plus flex-shrink-0 bg-default-200 text-default-800 rounded-full h-9 w-9 text-sm inline-flex items-center justify-center">+</button>
            </div>

            <a href="{{ route('second', ['client', 'cart']) }}" class="inline-flex items-center justify-center rounded-full border border-primary bg-primary px-10 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500">
                Buy Now
            </a>

            <i data-lucide="heart" class="h-8 w-8 text-default-400 cursor-pointer hover:fill-red-600 hover:text-red-600 focus:fill-red-600 focus:text-red-600"></i>
        </div>

        <div class="mb-6">
            <h4 class="text-lg font-medium text-default-700 mb-4">Nutrition Facts <span class="text-sm text-default-400">(per serving)</span></h4>

            <div class="border border-default-200 p-3 rounded-lg">
                <div class="grid grid-cols-4 justify-center">
                    <div class="text-center">
                        <h4 class="text-base font-medium text-default-700 mb-1">1524</h4>
                        <h4 class="text-base text-default-700">Calories</h4>
                    </div>
                    <div class="text-center">
                        <h4 class="text-base font-medium text-default-700 mb-1">56g</h4>
                        <h4 class="text-base text-default-700">Fat</h4>
                    </div>
                    <div class="text-center">
                        <h4 class="text-base font-medium text-default-700 mb-1">134g</h4>
                        <h4 class="text-base text-default-700">Carbs</h4>
                    </div>
                    <div class="text-center">
                        <h4 class="text-base font-medium text-default-700 mb-1">78g</h4>
                        <h4 class="text-base text-default-700">Protein</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex items-center">
            <i data-lucide="eye" class="w-5 h-5 me-2 text-primary"></i>
            <h5 class="text-sm text-default-600"><span class="text-primary font-semibold">152</span>&nbsp; People are viewing this right now</h5>
        </div>
    </div>
</div><!-- end grid -->

@endsection

@section('script')
@vite(['resources/js/product-detail.js', 'resources/js/form-input-spin.js'])
@endsection
